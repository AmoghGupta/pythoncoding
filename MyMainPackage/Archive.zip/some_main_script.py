def report_main():
    print("Hey I am a function inside a main script")