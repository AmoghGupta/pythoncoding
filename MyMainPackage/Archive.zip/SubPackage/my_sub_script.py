def sub_report():
    print("Hey I am a function inside a subscript")